#!/usr/bin/env python3
"""
Quality Control System Launcher
Automatically opens web browser and starts the system
"""

import subprocess
import webbrowser
import time
import sys
import os
from pathlib import Path

def check_dependencies():
    """Check if all required dependencies are installed"""
    required_packages = [
        'cv2', 'serial', 'websockets', 'ultralytics', 'numpy'
    ]
    
    missing_packages = []
    
    for package in required_packages:
        try:
            if package == 'cv2':
                import cv2
            elif package == 'serial':
                import serial
            elif package == 'websockets':
                import websockets
            elif package == 'ultralytics':
                from ultralytics import YOLO
            elif package == 'numpy':
                import numpy
        except ImportError:
            missing_packages.append(package)
    
    if missing_packages:
        print("❌ Missing required packages:")
        for pkg in missing_packages:
            print(f"   - {pkg}")
        print("\nInstall missing packages with:")
        print("pip install -r requirements.txt")
        return False
    
    return True

def check_model_file():
    """Check if YOLO model file exists"""
    model_path = Path("oppo-ai.pt")
    if not model_path.exists():
        print("❌ YOLO model file 'oppo-ai.pt' not found!")
        print("Please ensure your trained model file is in the same directory.")
        return False
    return True

def check_hardware():
    """Check hardware availability"""
    print("🔍 Checking hardware...")
    
    # Check camera
    try:
        import cv2
        cap = cv2.VideoCapture(0)
        ret, frame = cap.read()
        cap.release()
        if ret:
            print("✅ Camera detected")
        else:
            print("⚠️ Camera not detected or not working")
    except Exception as e:
        print(f"⚠️ Camera check failed: {e}")
    
    # Check serial ports
    try:
        import serial.tools.list_ports
        ports = serial.tools.list_ports.comports()
        if ports:
            print("✅ Available COM ports:")
            for port in ports:
                print(f"   - {port.device}: {port.description}")
        else:
            print("⚠️ No COM ports detected")
    except Exception as e:
        print(f"⚠️ Serial port check failed: {e}")

def main():
    """Main launcher function"""
    print("🚀 Quality Control System Launcher")
    print("="*50)
    
    # Check dependencies
    print("📦 Checking dependencies...")
    if not check_dependencies():
        input("Press Enter to exit...")
        return
    print("✅ All dependencies satisfied")
    
    # Check model file
    print("🤖 Checking YOLO model...")
    if not check_model_file():
        input("Press Enter to exit...")
        return
    print("✅ YOLO model found")
    
    # Check hardware
    check_hardware()
    
    print("\n" + "="*50)
    print("🎯 System Configuration")
    print("="*50)
    
    # Get configuration from user
    esp32_port = input("Enter ESP32 COM port (default: COM3): ").strip()
    if not esp32_port:
        esp32_port = "COM3"
    
    camera_id = input("Enter Camera ID (default: 0): ").strip()
    if not camera_id:
        camera_id = "0"
    else:
        try:
            camera_id = int(camera_id)
        except ValueError:
            camera_id = 0
    
    websocket_port = input("Enter WebSocket port (default: 8765): ").strip()
    if not websocket_port:
        websocket_port = "8765"
    else:
        try:
            websocket_port = int(websocket_port)
        except ValueError:
            websocket_port = 8765
    
    print(f"\n🔧 Configuration:")
    print(f"ESP32 Port: {esp32_port}")
    print(f"Camera ID: {camera_id}")
    print(f"WebSocket Port: {websocket_port}")
    print(f"YOLO Model: oppo-ai.pt")
    
    input("\nPress Enter to start the system...")
    
    # Update configuration in main script
    config_update = f"""
CONFIG = {{
    'esp32_port': '{esp32_port}',
    'camera_id': {camera_id},
    'model_path': 'oppo-ai.pt',
    'baud_rate': 115200,
    'websocket_port': {websocket_port}
}}
"""
    
    print("\n🚀 Starting Quality Control System...")
    print(f"📱 Web interface will open at: http://localhost:8000")
    print(f"🔌 WebSocket server: ws://localhost:{websocket_port}")
    
    # Open web browser after a delay
    def open_browser():
        time.sleep(3)  # Give server time to start
        try:
            # Try to open the HTML file directly
            html_file = Path("web_interface.html").absolute()
            if html_file.exists():
                webbrowser.open(f"file://{html_file}")
            else:
                print("⚠️ Web interface HTML file not found")
                print("Please open the HTML file manually in your browser")
        except Exception as e:
            print(f"⚠️ Could not open browser automatically: {e}")
    
    # Start browser opening in background
    import threading
    browser_thread = threading.Thread(target=open_browser, daemon=True)
    browser_thread.start()
    
    try:
        # Import and run the main system
        from main_web_controller import QualityControlWebSystem
        
        system_config = {
            'esp32_port': esp32_port,
            'camera_id': camera_id,
            'model_path': 'oppo-ai.pt',
            'baud_rate': 115200,
            'websocket_port': websocket_port
        }
        
        system = QualityControlWebSystem(**system_config)
        system.run()
        
    except ImportError:
        print("❌ Could not import main system. Ensure main_web_controller.py exists.")
    except KeyboardInterrupt:
        print("\n🛑 System stopped by user")
    except Exception as e:
        print(f"❌ System error: {e}")
    
    print("\n✅ System shutdown complete")
    input("Press Enter to exit...")

if __name__ == "__main__":
    main()