import cv2
import serial
import time
import threading
import asyncio
import websockets
import json
import base64
from queue import Queue
from ultralytics import YOLO
import numpy as np
from datetime import datetime
import os
import logging

# Setup logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class QualityControlWebSystem:
    def __init__(self, 
                 esp32_port='COM3',
                 camera_id=0,
                 model_path='oppo-ai.pt',
                 baud_rate=115200,
                 websocket_port=8765):
        
        # Configuration
        self.esp32_port = esp32_port
        self.camera_id = camera_id
        self.model_path = model_path
        self.baud_rate = baud_rate
        self.websocket_port = websocket_port
        
        # State variables
        self.ir_detected = False
        self.defect_detected = False
        self.relay_status = True  # True = ON, False = OFF
        self.system_running = False
        self.last_classification = "IDLE"
        self.classification_changed = False
        
        # Communication
        self.serial_connection = None
        self.camera = None
        self.yolo_model = None
        self.connected_clients = set()
        
        # Data storage
        self.current_detections = []
        self.results_log = []
        
        # Initialize components
        self.init_serial()
        self.init_camera()
        self.init_yolo()
        
    def init_serial(self):
        """Initialize ESP32 serial communication"""
        try:
            self.serial_connection = serial.Serial(
                port=self.esp32_port,
                baudrate=self.baud_rate,
                timeout=1
            )
            time.sleep(2)  # Wait for ESP32 initialization
            
            # Test connection
            self.serial_connection.write(b"PING\n")
            time.sleep(0.1)
            response = self.serial_connection.readline().decode('utf-8').strip()
            
            if "PONG" in response:
                logger.info(f"✓ ESP32 connected on {self.esp32_port}")
                return True
            else:
                raise Exception("ESP32 not responding to PING")
                
        except Exception as e:
            logger.error(f"✗ Failed to connect ESP32: {e}")
            self.serial_connection = None
            return False
    
    def init_camera(self):
        """Initialize USB camera"""
        try:
            self.camera = cv2.VideoCapture(self.camera_id)
            self.camera.set(cv2.CAP_PROP_FRAME_WIDTH, 640)
            self.camera.set(cv2.CAP_PROP_FRAME_HEIGHT, 480)
            self.camera.set(cv2.CAP_PROP_FPS, 30)
            
            ret, frame = self.camera.read()
            if ret:
                logger.info("✓ Camera initialized successfully")
                return True
            else:
                raise Exception("Cannot read from camera")
                
        except Exception as e:
            logger.error(f"✗ Failed to initialize camera: {e}")
            self.camera = None
            return False
    
    def init_yolo(self):
        """Initialize YOLO model"""
        try:
            if os.path.exists(self.model_path):
                self.yolo_model = YOLO(self.model_path)
                logger.info(f"✓ YOLO model loaded: {self.model_path}")
                return True
            else:
                raise Exception(f"Model file not found: {self.model_path}")
                
        except Exception as e:
            logger.error(f"✗ Failed to load YOLO model: {e}")
            self.yolo_model = None
            return False
    
    def read_ir_sensor(self):
        """Thread untuk membaca sensor IR secara kontinyu"""
        while self.system_running:
            if self.serial_connection and self.serial_connection.in_waiting:
                try:
                    line = self.serial_connection.readline().decode('utf-8').strip()
                    
                    if line == "IR:DETECTED":
                        if not self.ir_detected:  # State changed
                            self.ir_detected = True
                            logger.info("📱 HP Unit detected by IR sensor")
                    elif line == "IR:NOT_DETECTED":
                        if self.ir_detected:  # State changed
                            self.ir_detected = False
                            logger.info("🚫 No HP Unit detected by IR sensor")
                    elif "RELAY:" in line:
                        status = line.split(":")[1]
                        if status in ["ON", "ON_OK"]:
                            self.relay_status = True
                        elif status in ["OFF", "OFF_OK"]:
                            self.relay_status = False
                            
                except Exception as e:
                    logger.error(f"Error reading serial: {e}")
            
            time.sleep(0.05)
    
    def detect_defects(self, frame):
        """Deteksi defect menggunakan YOLO"""
        if self.yolo_model is None:
            return False, frame, []
        
        try:
            results = self.yolo_model(frame)
            detections = []
            defect_found = False
            
            # Target classes: Gelembung, Gelembung Pinggir, Bintik
            target_classes = ['Gelembung', 'Gelembung Pinggir', 'Bintik']
            
            for result in results:
                boxes = result.boxes
                if boxes is not None:
                    for box in boxes:
                        confidence = box.conf[0].item()
                        if confidence > 0.5:  # Confidence threshold
                            class_id = int(box.cls[0].item())
                            class_name = self.yolo_model.names[class_id]
                            
                            # Check if detected class is a defect type
                            if class_name in target_classes:
                                defect_found = True
                                
                                # Get bounding box
                                x1, y1, x2, y2 = box.xyxy[0].int().tolist()
                                
                                detections.append({
                                    'class': class_name,
                                    'confidence': confidence,
                                    'bbox': [x1, y1, x2, y2]
                                })
                                
                                # Draw bounding box
                                color = (0, 0, 255)  # Red for defects
                                cv2.rectangle(frame, (x1, y1), (x2, y2), color, 2)
                                cv2.putText(frame, f'{class_name}: {confidence:.2f}', 
                                          (x1, y1-10), cv2.FONT_HERSHEY_SIMPLEX, 
                                          0.6, color, 2)
            
            self.current_detections = detections
            return defect_found, frame, detections
            
        except Exception as e:
            logger.error(f"Error in defect detection: {e}")
            return False, frame, []
    
    def classify_unit(self, ir_status, defect_status):
        """Klasifikasi unit berdasarkan IR dan deteksi defect"""
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        
        # Determine classification
        if not ir_status:
            classification = "NO_DETECTION"
            status = "⏸️ No Detection - Waiting for unit"
        elif ir_status and not defect_status:
            classification = "UNIT_NORMAL"
            status = "✅ Unit Normal - No defects detected"
        elif ir_status and defect_status:
            classification = "UNIT_DEFECT"
            status = "❌ Unit Defect - Screen defects found"
        else:
            classification = "IDLE"
            status = "⏸️ System Idle"
        
        # Check if classification changed
        self.classification_changed = (classification != self.last_classification)
        self.last_classification = classification
        
        # Control relay based on classification
        if classification == "UNIT_DEFECT":
            self.control_relay(False)  # Turn OFF relay for defects
        else:
            self.control_relay(True)   # Turn ON relay for normal/no detection
        
        # Log result
        result = {
            'timestamp': timestamp,
            'ir_status': ir_status,
            'defect_status': defect_status,
            'classification': classification,
            'status': status,
            'detections': self.current_detections
        }
        
        if self.classification_changed:
            self.results_log.append(result)
            logger.info(f"{timestamp} - {status}")
        
        return result
    
    def control_relay(self, turn_on):
        """Control ESP32 relay"""
        if self.serial_connection:
            try:
                command = "RELAY_ON\n" if turn_on else "RELAY_OFF\n"
                self.serial_connection.write(command.encode('utf-8'))
                
                # Don't wait for response to avoid blocking
                # Response will be handled in read_ir_sensor thread
                
            except Exception as e:
                logger.error(f"Error controlling relay: {e}")
    
    def capture_and_process_frame(self):
        """Capture frame and process for defects"""
        if self.camera is None:
            return None, []
        
        ret, frame = self.camera.read()
        if not ret:
            return None, []
        
        # Detect defects
        defect_found, annotated_frame, detections = self.detect_defects(frame)
        self.defect_detected = defect_found
        
        return annotated_frame, detections
    
    def frame_to_base64(self, frame):
        """Convert frame to base64 for web transmission"""
        if frame is None:
            return None
        
        try:
            # Encode frame as JPEG
            ret, buffer = cv2.imencode('.jpg', frame, [cv2.IMWRITE_JPEG_QUALITY, 80])
            if ret:
                # Convert to base64
                img_base64 = base64.b64encode(buffer).decode('utf-8')
                return img_base64
            return None
        except Exception as e:
            logger.error(f"Error converting frame to base64: {e}")
            return None
    
    async def websocket_handler(self, websocket, path):
        """Handle WebSocket connections"""
        self.connected_clients.add(websocket)
        logger.info(f"Client connected. Total clients: {len(self.connected_clients)}")
        
        try:
            async for message in websocket:
                try:
                    data = json.loads(message)
                    command = data.get('command')
                    
                    if command == 'reset':
                        await self.handle_reset_command()
                    elif command == 'save':
                        await self.handle_save_command()
                    elif command == 'test_relay':
                        await self.handle_test_relay()
                    
                except json.JSONDecodeError:
                    logger.error("Invalid JSON received from client")
                    
        except websockets.exceptions.ConnectionClosed:
            pass
        finally:
            self.connected_clients.discard(websocket)
            logger.info(f"Client disconnected. Total clients: {len(self.connected_clients)}")
    
    async def handle_reset_command(self):
        """Handle system reset command"""
        if self.serial_connection:
            self.serial_connection.write(b"RESET\n")
        
        # Reset internal state
        self.ir_detected = False
        self.defect_detected = False
        self.relay_status = True
        self.current_detections = []
        
        logger.info("System reset command executed")
    
    async def handle_save_command(self):
        """Handle save results command"""
        self.save_results()
    
    async def handle_test_relay(self):
        """Handle relay test command"""
        if self.serial_connection:
            # Toggle relay for test
            self.serial_connection.write(b"RELAY_OFF\n")
            await asyncio.sleep(1)
            self.serial_connection.write(b"RELAY_ON\n")
            logger.info("Relay test executed")
    
    async def broadcast_data(self):
        """Broadcast current system status to all connected clients"""
        if not self.connected_clients:
            return
        
        # Capture and process current frame
        frame, detections = self.capture_and_process_frame()
        
        # Classify current state
        result = self.classify_unit(self.ir_detected, self.defect_detected)
        
        # Prepare data for web interface
        data = {
            'ir_detected': self.ir_detected,
            'defect_detected': self.defect_detected,
            'relay_status': self.relay_status,
            'classification': result['classification'],
            'classification_changed': self.classification_changed,
            'detections': detections,
            'image_data': self.frame_to_base64(frame),
            'timestamp': result['timestamp']
        }
        
        # Send to all connected clients
        if self.connected_clients:
            message = json.dumps(data)
            disconnected_clients = []
            
            for client in self.connected_clients:
                try:
                    await client.send(message)
                except websockets.exceptions.ConnectionClosed:
                    disconnected_clients.append(client)
                except Exception as e:
                    logger.error(f"Error sending data to client: {e}")
                    disconnected_clients.append(client)
            
            # Remove disconnected clients
            for client in disconnected_clients:
                self.connected_clients.discard(client)
    
    def save_results(self, filename=None):
        """Save results to file"""
        if filename is None:
            filename = f"quality_control_log_{datetime.now().strftime('%Y%m%d_%H%M%S')}.txt"
        
        try:
            with open(filename, 'w', encoding='utf-8') as f:
                f.write("Quality Control System Log\n")
                f.write("="*50 + "\n\n")
                f.write(f"Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n\n")
                
                # Summary statistics
                total_units = len(self.results_log)
                normal_count = sum(1 for r in self.results_log if r['classification'] == 'UNIT_NORMAL')
                defect_count = sum(1 for r in self.results_log if r['classification'] == 'UNIT_DEFECT')
                
                f.write("SUMMARY STATISTICS\n")
                f.write(f"Total Units Processed: {total_units}\n")
                f.write(f"Normal Units: {normal_count}\n")
                f.write(f"Defect Units: {defect_count}\n")
                if total_units > 0:
                    success_rate = (normal_count / total_units) * 100
                    f.write(f"Success Rate: {success_rate:.1f}%\n")
                f.write("\n" + "-"*50 + "\n\n")
                
                # Detailed log
                f.write("DETAILED LOG\n")
                for i, result in enumerate(self.results_log, 1):
                    f.write(f"{i}. {result['timestamp']}\n")
                    f.write(f"   IR Status: {'Detected' if result['ir_status'] else 'Not Detected'}\n")
                    f.write(f"   Defect Status: {'Found' if result['defect_status'] else 'None'}\n")
                    f.write(f"   Classification: {result['classification']}\n")
                    f.write(f"   Status: {result['status']}\n")
                    
                    if result['detections']:
                        f.write("   Detected Defects:\n")
                        for detection in result['detections']:
                            f.write(f"     - {detection['class']}: {detection['confidence']:.1%}\n")
                    f.write("\n")
            
            logger.info(f"✓ Results saved to {filename}")
            return True
            
        except Exception as e:
            logger.error(f"✗ Failed to save results: {e}")
            return False
    
    async def run_async_loop(self):
        """Main async loop for broadcasting data"""
        while self.system_running:
            try:
                await self.broadcast_data()
                await asyncio.sleep(0.1)  # 10 FPS update rate
            except Exception as e:
                logger.error(f"Error in async loop: {e}")
                await asyncio.sleep(1)
    
    def run(self):
        """Start the complete system"""
        if not all([self.serial_connection, self.camera, self.yolo_model]):
            logger.error("✗ System initialization failed. Cannot start.")
            return False
        
        logger.info("\n🚀 Quality Control Web System Starting...")
        logger.info(f"WebSocket server will run on ws://localhost:{self.websocket_port}")
        logger.info("Open the web interface in your browser")
        
        self.system_running = True
        
        # Start IR sensor reading thread
        ir_thread = threading.Thread(target=self.read_ir_sensor, daemon=True)
        ir_thread.start()
        
        # Start WebSocket server and async loop
        async def main():
            # Start WebSocket server
            server = await websockets.serve(
                self.websocket_handler,
                "localhost",
                self.websocket_port
            )
            logger.info(f"✓ WebSocket server started on port {self.websocket_port}")
            
            # Run the main async loop
            await self.run_async_loop()
        
        try:
            asyncio.run(main())
        except KeyboardInterrupt:
            logger.info("🛑 System interrupted by user")
        except Exception as e:
            logger.error(f"System error: {e}")
        finally:
            self.cleanup()
        
        return True
    
    def cleanup(self):
        """Clean up all resources"""
        logger.info("🧹 Cleaning up system resources...")
        
        self.system_running = False
        
        if self.camera:
            self.camera.release()
            logger.info("✓ Camera released")
        
        if self.serial_connection:
            try:
                self.serial_connection.write(b"RESET\n")
                self.serial_connection.close()
                logger.info("✓ Serial connection closed")
            except:
                pass
        
        logger.info("🧹 System cleanup completed")

def main():
    """Main entry point"""
    # Configuration - SESUAIKAN DENGAN SETUP ANDA
    CONFIG = {
        'esp32_port': 'COM3',        # Port ESP32 (check Device Manager)
        'camera_id': 0,              # Camera ID (biasanya 0)
        'model_path': 'oppo-ai.pt',  # Path ke YOLO model Anda
        'baud_rate': 115200,         # Baud rate untuk serial
        'websocket_port': 8765       # Port untuk WebSocket server
    }
    
    print("🔧 Quality Control Web System")
    print("="*50)
    print("Hardware Configuration:")
    print(f"ESP32 Port: {CONFIG['esp32_port']}")
    print(f"Camera ID: {CONFIG['camera_id']}")
    print(f"YOLO Model: {CONFIG['model_path']}")
    print(f"WebSocket Port: {CONFIG['websocket_port']}")
    print("="*50)
    
    # Initialize and run system
    system = QualityControlWebSystem(**CONFIG)
    success = system.run()
    
    if success:
        logger.info("✅ System completed successfully")
    else:
        logger.error("❌ System failed to start")
    
    return success

if __name__ == "__main__":
    main()